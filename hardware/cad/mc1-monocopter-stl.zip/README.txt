MC-1 monocopter printable parts: binary STL, millimetres, already in print orientation (z up).
Quantities, materials and settings: see the parts page of the build guide and docs/printing.md.
